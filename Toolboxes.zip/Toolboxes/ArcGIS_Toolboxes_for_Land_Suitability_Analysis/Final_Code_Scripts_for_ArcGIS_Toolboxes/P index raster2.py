# Python script to identify area based on Pennsylvania P Index classification and create rasters
# Python version 2.7.16
# Associated with 'Pennsylvania_P_Index_based_Area_Classification_Toolbox'
# ArcMap 10.7.1 was used to create toolbox
# Date of creation: December 10, 2019

# importing arcpy and related module
import arcpy
import math
from arcpy import env
from arcpy.sa import *
arcpy.env.overwriteOutput = True


# Defining input parameters 
#inputLndUseRaster = "C:/GKS/Land Suitability Framework_new/Landuse/Raster/CDL_Proj/lndusprj"
inputLndUseRaster = arcpy.GetParameterAsText(0)
#inLndRemapFile = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs/LU_Reclass_Lookup_Pennsylvania_general_class_new1.txt"
inLndRemapFile = arcpy.GetParameterAsText(1)
#inputStudy = "C:/GKS/Land Suitability Framework_new/Test Case/TestStudy.shp"
inputStudy = arcpy.GetParameterAsText(2)

#inSoilTestPRemapFile = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs/GLU_Reclass_Lookup_Soil Test P.txt"
inSoilTestPRemapFile = arcpy.GetParameterAsText(3)

#inputFertPRate =
inputFertPRate = arcpy.GetParameterAsText(4)

#inputfertAppMetd =
inputfertAppMetd = arcpy.GetParameterAsText(5)

#inputMnrPRate =
inputMnrPRate = arcpy.GetParameterAsText(6)

#inputMnrAppMetd =
inputMnrAppMetd = arcpy.GetParameterAsText(7)

#inputPSrcCoeff =
inputPSrcCoeff = arcpy.GetParameterAsText(8)

#inputPrecipFeature = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs/Station_all_proj.shp"
inputPrecipFeature = arcpy.GetParameterAsText(9)
#inputKFactor = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs/Kfact3Conty_prj1.shp"
inputKFactor = arcpy.GetParameterAsText(10)
#inputDemRaster = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs/dem_project.tif"
inputDemRaster = arcpy.GetParameterAsText(11)
#inputSoilFeature = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs/Soil_Proj.shp"
inputSoilFeature = arcpy.GetParameterAsText(12)
#inputSubSurfDrain = 1.0
inputSubSurfDrain = arcpy.GetParameterAsText(13)
#inputNHDFeature = "C:/GKS/Land Suitability Framework_new/Input features and rasters/NHD_all.shp"
inputNHDFeature = arcpy.GetParameterAsText(14)
#inputModifiedConnectivity = 1.0
inputModifiedConnectivity = arcpy.GetParameterAsText(15)

#outputFolder = "C:/GKS/Land Suitability Framework_new/Output Folder"
outputFolder = arcpy.GetParameterAsText(16)

# Defining workspace
env.workspace = outputFolder

# Define study area extent for raster     
arcpy.env.extent = inputStudy

try:
  
  #### Source factor calculation
  ## Soil Test Rating Calculation

  decFertAppMetd = {"Placed or injected 2 inches or deeper": 0.2, "Incorporated less than 1 week following application": 0.4, "Incorporated more than 1 week or not incorporated following application in April to October": 0.6, "Incorporated more than 1 week or not incorporated following application in November to March": 0.8, "Surface applied to frozen or snow-covered soil": 1.0}
  decMnrAppMetd = {"Placed or injected 2 inches or more deep": 0.2, "Incorporated less than 1 week following application": 0.4, "Incorporated more than 1 week or not incorporated following application in April to October": 0.6, "Incorporated more than 1 week or not incorporated following application in November to March": 0.8, "Surface applied to frozen or snow-covered soil": 1.0}
  decPSrcCoeff = {"Swine": 1.0, "Broiler": 0.8, "Layer": 0.8, "Turkey": 0.8, "Duck": 1.0, "Dairy-Liquid": 0.8, "Dairy-Bedded Pack": 0.8, "Beef": 0.8, "Horse": 0.8, "BPR Biosolids": 0.8, "All Biosolids (Except BPR)": 0.4}


  # Extracting and saving raster
  arcpy.CheckOutExtension("Spatial")
  outExtractByMask = ExtractByMask(inputLndUseRaster, inputStudy)
  clpLndRaster = outputFolder + "\\" + "ClpdLndUse"
  outExtractByMask.save(clpLndRaster)
  arcpy.CheckInExtension ("Spatial")

  # Landuse reclassification for broader landuse classes
  # Reclassification with reclassify by ascii tool 
  arcpy.CheckOutExtension("Spatial")
  lndReclass = ReclassByASCIIFile(clpLndRaster, inLndRemapFile)
  lndRaster = outputFolder + "\\" + "RclLandUses"
  lndReclass.save(lndRaster)
  arcpy.CheckInExtension ("Spatial")

  # For Soil Test P raster

  # Broader landuse reclassification with reclassify by ascii tool to categorize
  ## into soil test p based on broader landuse classes
  arcpy.CheckOutExtension("Spatial")
  soilTestPReclass = ReclassByASCIIFile(lndRaster, inSoilTestPRemapFile)
  outSoilTestPReclass = outputFolder + "\\" + "soil_test_P"
  soilTestPReclass.save(outSoilTestPReclass)
  arcpy.CheckInExtension ("Spatial")

  # Calculation of soil test rating 
  arcpy.CheckOutExtension("Spatial")
  soilTestRate = 0.20 * Raster("soil_test_P")
  outSoilTestRate = outputFolder + "\\" + "soil_test_rt"
  soilTestRate.save(outSoilTestRate)
  arcpy.CheckInExtension ("Spatial")

  # Fertilizer P Rate (lb P2O5/acre) input
  #fertPRate = 10.0
  fertPRate = float(inputFertPRate)

  # Fertilizer Application Method
  #fertAppMetd = 0.6
  fertAppMetd = float(decFertAppMetd[inputfertAppMetd])

  # Fertilizer rating calculation
  fertRate = fertPRate * fertAppMetd


  # Manure P Rate (lb P2O5/acre) input
  #mnrPRate = 87.0
  mnrPRate = float(inputMnrPRate)

  # Manure Application Method
  #mnrAppMetd = 0.6
  mnrAppMetd = float(decMnrAppMetd[inputMnrAppMetd])

  # P source coefficient
  #pSrcCoeff = 0.8
  pSrcCoeff = float(decPSrcCoeff[inputPSrcCoeff])

  # Manure rating calculation
  mnrRate = mnrPRate * mnrAppMetd * pSrcCoeff


  # Calculation of source factor
  arcpy.CheckOutExtension("Spatial")
  sourceFact = Raster("soil_test_rt") + fertRate + mnrRate
  outSourceFact = outputFolder + "\\" + "src_fact"
  sourceFact.save(outSourceFact)
  arcpy.CheckInExtension ("Spatial")



  ##### Transport factor calculation

  # Erosion calculation
  # R Factor calculation
  # Copy the input precipitation for R Factor 
  precipRFact = arcpy.Copy_management(inputPrecipFeature, "precipRFact.shp")

  # Add field in the precipitation shapefile
  arcpy.AddField_management(precipRFact, "RFact", "FLOAT")

  # Updating R Factor information
  with arcpy.da.UpdateCursor(precipRFact, ['Pcp_Anl_mm','RFact']) as rfactfile:
      for row_rfactfile in rfactfile:
          # Suitability Criteria
          if row_rfactfile[0] < 850:
             row_rfactfile[1] = (0.04830*row_rfactfile[0]**1.610)*0.05876
          else:
             row_rfactfile[1] = (587.8-1.219*row_rfactfile[0]+0.004105*row_rfactfile[0]**2.0)*0.05876

          rfactfile.updateRow(row_rfactfile) #  Unit of R factor: Mj.mm.ha-1.h-1.year-1

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Input extent
  arcpy.env.extent = inputStudy
  # Apply Inverse Distance Weighting function to calculate R Factor
  IDWrFact = arcpy.gp.Idw_sa(precipRFact, "RFact", "intRFact", "30", "2", "VARIABLE 12", "")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Mask the slope within study
  fnlRFact = arcpy.gp.ExtractByMask_sa(IDWrFact, inputStudy, "rFactor") #  Unit of R factor: Mj.mm.ha-1.h-1.year-1
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")


  # K Factor calculation
  # Input extent
  arcpy.env.extent = inputStudy
   # Execute FeatureToRaster
  kFactor = arcpy.FeatureToRaster_conversion(inputKFactor, "KfactWS1", "kFactor", 30) # unit of K factor: tons per acre per year


  # LS Factor calculation
  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Percent slope development
  prcSlope = arcpy.gp.Slope_sa(inputDemRaster,"slp_prc","PERCENT_RISE", "1")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Degree slope development
  degSlope = arcpy.gp.Slope_sa(inputDemRaster,"slp_deg","DEGREE", "1")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: Resample
  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Resample of percent slope
  arcpy.env.extent = inputStudy
  rsmplSlope = arcpy.Resample_management(prcSlope, "slp_rsmp", "30 30", "NEAREST")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Resample of percent slope
  arcpy.env.extent = inputStudy
  rsmpDeglSlope = arcpy.Resample_management(degSlope, "slp_deg_rsmp", "30 30", "NEAREST")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: Extract by Mask
  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Mask the percent slope within study
  clipSlope = arcpy.gp.ExtractByMask_sa(rsmplSlope, inputStudy, "clp_Rsmp_Slp")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Mask the percent slope within study
  clipDegSlope = arcpy.gp.ExtractByMask_sa(rsmpDeglSlope, inputStudy, "clp_RsDeg_Slp")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # m factor calculation that ultimately required to calculate LS Factor
  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Calculating m factor for LS Factor calculation
  mFactor = arcpy.gp.RasterCalculator_sa("0.6 * (1 - Exp((-1)*(35.835 *\"clp_Rsmp_Slp\" / 100)))", "mFact")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Check out the ArcGIS Spatial Analyst extension license 
  arcpy.CheckOutExtension("Spatial")
  # Reclassify percent slope raster to calculate Slope length
  slopeLengthReclass = Reclassify(clipSlope, "VALUE", RemapRange([[0,2.5,122],[2.5,5.5,91],[5.5,8.5,61],[8.5,12.5,37],[12.5,16.5,24],[16.5,20.5,18],[20.5,25.5,15],[25.5,50,8],[50,145,5]]))
  slopeLengthRaster = outputFolder + "\\" + "Slp_Length" # slope length in 'meter'
  slopeLengthReclass.save(slopeLengthRaster)
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: LS Factor Calculation
  # Check out the ArcGIS Spatial Analyst extension license 
  arcpy.CheckOutExtension("Spatial")
  # Calculate LS Factor by using raster calculation
  fnlLSfact = arcpy.gp.RasterCalculator_sa("Power(\"Slp_Length\"/22.1,\"mFact\")*(65.41 * Square(Sin(\"clp_RsDeg_Slp\"/57.296))+4.56*Sin(\"clp_RsDeg_Slp\"/57.296)+0.065)", "lsFactor")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")


  # C Factor calculation
  # Extracting and saving raster
  arcpy.CheckOutExtension("Spatial")
  outExtractByMask = ExtractByMask(inputLndUseRaster, inputStudy)
  outRaster = outputFolder + "\\" + "ClpdLndUse"
  outExtractByMask.save(outRaster)
  arcpy.CheckInExtension ("Spatial")

  # Landuse reclassification for broader landuse classes
  # Reclassification with reclassify tool 
  arcpy.CheckOutExtension("Spatial")
  lndReclass = Reclassify(outRaster, "Value", RemapValue([[0,4],[1,1],[2,1],[3,1],[4,1],[5,1],[6,4],[10,1],[11,1],[12,1],[13,1],[14,1],[21,1],[22,1],[23,1],[24,1],[25,1],[26,1],[27,1],[28,1],[29,1],[30,1],[31,1],[32,1],[33,1],[34,1],[35,1],[36,2],[37,2],[38,4],[39,1],[41,1],[42,4],[43,4],[44,1],[45,1],[46,1],[47,4],[48,4],[49,1],[50,4],[51,4],[52,1],[53,4],[54,4],[55,4],[56,4],[57,1],[58,2],[59,2],[60,2],[61,3],[62,2],[63,4],[64,4],[65,3],[66,4],[67,4],[68,4],[69,4],[70,4],[71,4],[72,4],[74,4],[75,4],[76,4],[77,4],[81,4],[82,4],[83,4],[87,4],[88,4],[92,4],[111,4],[112,4],[121,4],[122,4],[123,4],[124,4],[131,3],[141,4],[142,4],[143,4],[152,4],[176,2],[190,4],[195,4],[204,4],[205,1],[206,4],[207,4],[208,4],[209,4],[210,4],[211,4],[212,4],[213,4],[214,4],[215,4],[216,4],[217,4],[218,4],[219,4],[220,4],[221,4],[222,4],[223,4],[224,1],[225,1],[226,1],[227,1],[229,4],[230,1],[231,4],[232,1],[233,1],[234,1],[235,1],[236,1],[237,1],[238,1],[239,1],[240,1],[241,1],[242,4],[243,4],[244,4],[245,1],[246,1],[247,1],[248,4],[249,4],[250,4],[254,1]]))
  lndRaster = outputFolder + "\\" + "RclLandUses"
  lndReclass.save(lndRaster)
  arcpy.CheckInExtension ("Spatial")

  # Reclassification with reclassify tool to get C factor
  arcpy.CheckOutExtension("Spatial")
  cFacReclass = Reclassify(lndReclass, "Value", RemapValue([[0,0],[1,30],[2,4],[3,1000],[4,0]]))
  cFacRaster = outputFolder + "\\" + "cFactor" # unitles, it is a ratio.
  cFacReclass.save(cFacRaster)
  arcpy.CheckInExtension ("Spatial")


  # P Factor calculation
  # Check out the ArcGIS Spatial Analyst extension license 
  arcpy.CheckOutExtension("Spatial")
  # Reclassify percent slope raster to calculate Slope length
  pFactReclass = Reclassify(clipSlope, "VALUE", RemapRange([[0,2.5,6],[2.5,5.5,5],[5.5,8.5,5],[8.5,12.5,6],[12.5,16.5,7],[16.5,20.5,8],[20.5,25.5,9],[25.5,50,10],[50,145,10]]))
  pFactRaster = outputFolder + "\\" + "pFactor" # unit in 'meter'
  pFactReclass.save(pFactRaster)
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Erosion calculation
  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Create interim soil erosion raster within study 
  outIntrmSoilErsn = outputFolder + "\\" + "int_soil_ersn"
  IntrmSoilErsn = Raster("rFactor")*Raster("kFactor")*Raster("lsFactor")*Raster("cFactor")*Raster("pFactor")
  IntrmSoilErsn.save(outIntrmSoilErsn)
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Create interim soil erosion raster within study 
  outFnlSoilErsn = outputFolder + "\\" + "soil_erosion"
  FnlSoilErsn = Raster("int_soil_ersn")/10000
  FnlSoilErsn.save(outFnlSoilErsn)
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")


  # Runoff Potential Calculation
  # Copy of soil data 
  soilInfo = arcpy.Copy_management(inputSoilFeature, "soilInfo.shp")

  # Add field in the precipitation shapefile
  arcpy.AddField_management(soilInfo, "DrngClsVal", "SHORT")

  # Updating R Factor information
  with arcpy.da.UpdateCursor(soilInfo, ['drainagecl','DrngClsVal']) as drainagefile:
      for row_drainagefile in drainagefile:
          # Suitability Criteria
          if row_drainagefile[0] == "Extremely drained":
             row_drainagefile[1] = 0
          elif row_drainagefile[0] == "Somewhat exessively drained":
             row_drainagefile[1] = 2
          elif row_drainagefile[0] == "Well drained":
             row_drainagefile[1] = 4
          elif row_drainagefile[0] == "Moderately well drained":
             row_drainagefile[1] = 4
          elif row_drainagefile[0] == "Somewhat poorly drained":
             row_drainagefile[1] = 6
          elif row_drainagefile[0] == "Poorly drained":
             row_drainagefile[1] = 8
          elif row_drainagefile[0] == "Very poorly drained":
             row_drainagefile[1] = 8
          else:
             row_drainagefile[1] = 8

          drainagefile.updateRow(row_drainagefile)

  # Input extent
  arcpy.env.extent = inputStudy
  # Execute FeatureToRaster
  runoffPotential = arcpy.FeatureToRaster_conversion(soilInfo, "DrngClsVal", "runoffPotnl", 30)

  # Subsurface Drainage Component
  # Defining a dictionary of 'subsurface drainage values based on their designated pattern
  decSubsurfaceDrainage = {"None": 0, "Random": 1, "Patterned": 2}
  #SubsurfaceDrainage = 0
  reqSubSurfDrainage = float(decSubsurfaceDrainage[inputSubSurfDrain])


  # Contributing distance calculation
  # Process: Clip
  clipNHD = arcpy.Clip_analysis(inputNHDFeature, inputStudy, "NHDclip.shp", "")
  # Process: Dissolve
  dslvClipNHD = arcpy.Dissolve_management(clipNHD, "dslvClipNHD.shp", "", "", "MULTI_PART", "DISSOLVE_LINES")

  # Process: 100 Feet Buffer Calculation
  buff100 = arcpy.Buffer_analysis(dslvClipNHD, "buff100.shp", "100 Feet", "FULL", "ROUND", "NONE", "", "PLANAR")
  # Process: 200 Feet Buffer Calculation
  buff200 = arcpy.Buffer_analysis(dslvClipNHD, "buff200.shp", "200 Feet", "FULL", "ROUND", "NONE", "", "PLANAR")

  # Process: Dissolve
  RA100 = arcpy.Dissolve_management(buff100, "ra100.shp", "", "", "MULTI_PART", "DISSOLVE_LINES")
  # Process: Assigning Contributing Distance
  arcpy.CalculateField_management(RA100, "Id", "9", "VB", "")
  # Process: Erase (From 200 Feet to 100 Feet)
  EA200to100 = arcpy.Erase_analysis(buff200, buff100, "ea200to100.shp", "")
  # Process: Dissolve
  RA200to100 = arcpy.Dissolve_management(EA200to100, "ra200to100.shp", "", "", "MULTI_PART", "DISSOLVE_LINES")
  # Process: Assigning Contributing Distance
  arcpy.CalculateField_management(RA200to100, "Id", "6", "VB", "")


  # Process: 350 Feet Buffer Calculation
  buff350 = arcpy.Buffer_analysis(dslvClipNHD, "buff350.shp", "350 Feet", "FULL", "ROUND", "NONE", "", "PLANAR")
  # Process: Erase (From 350 Feet to 200 Feet)
  EA350to200 = arcpy.Erase_analysis(buff350, buff200, "ea350to200.shp", "")
  # Process: Dissolve
  RA350to200 = arcpy.Dissolve_management(EA350to200, "ra350to200.shp", "", "", "MULTI_PART", "DISSOLVE_LINES")
  # Process: Assigning Contributing Distance
  arcpy.CalculateField_management(RA350to200, "Id", "4", "VB", "")

  # Process: 500 Feet Buffer Calculation
  buff500 = arcpy.Buffer_analysis(dslvClipNHD, "buff500.shp", "500 Feet", "FULL", "ROUND", "NONE", "", "PLANAR")
  # Process: Erase (From 500 Feet to 350 Feet)
  EA500to350 = arcpy.Erase_analysis(buff500, buff350, "ea500to350.shp", "")
  # Process: Dissolve
  RA500to350 = arcpy.Dissolve_management(EA500to350, "ra500to350.shp", "", "", "MULTI_PART", "DISSOLVE_LINES")
  # Process: Assigning Contributing Distance
  arcpy.CalculateField_management(RA500to350, "Id", "2", "VB", "")

  # Process: Dissolve
  outsideBuffer = arcpy.Dissolve_management(inputStudy, "outsideBuff.shp", "", "", "MULTI_PART", "DISSOLVE_LINES")
  # Process: Merge management
  MergeBuffer = arcpy.Merge_management([RA100, RA200to100, RA350to200, RA500to350, outsideBuffer], "mergeBuffer.shp")
  # Define study area extent for raster      
  arcpy.env.extent = inputStudy
   
  # Execute Feature To Raster
  contrbtDist = arcpy.FeatureToRaster_conversion(MergeBuffer, "Id", "cont_distance", 30)


  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Creat interim raster with factored hydrologic soil group and annual precipitation within study
  outTransportSum = outputFolder + "\\" + "trnspt_sum"
  TransportSum = Raster("soil_erosion") + Raster("runoffPotnl") + Raster("cont_distance") + reqSubSurfDrainage
  TransportSum.save(outTransportSum)
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")


  # Modified connectivity factor selection 
  decModifiedConnectivity = {"50-foot Riparian Buffer Applies to distances less than 100 feet": 0.85, "Grassed Waterway or None": 1.0, "Direct Connection Applies to distances greater than 100 feet": 1.1}
  #ModifiedConnectivity = 1.0
  reqModConnect = float(decModifiedConnectivity[inputModifiedConnectivity])


  # Transport Factor Calculation
  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Calculating m factor for LS Factor calculation
  outTransportFactor = outputFolder + "\\" + "trnspt_fact"
  transportFactor = Raster("trnspt_sum") * reqModConnect / 24.0
  transportFactor.save(outTransportFactor)
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")


  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Calculating m factor for LS Factor calculation
  outPIndex = outputFolder + "\\" + "p_index_val"
  PIndexVal = Raster("src_fact") * Raster("trnspt_fact") * 2.0
  PIndexVal.save(outPIndex)
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")


  # P Index reclassification to assign suitability criteria
  # Reclassification with reclassify tool

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Create a range for reclassification
  PIndxRemapRange = RemapRange([[0, 59.5, 1], [59.5, 79.5, 2], [79.5, 99.5, 3],[99.5, 10000, 4]])
  # Reclassification of leaching index to create suitability index by using remap range
  PIndxReclass = Reclassify(outPIndex, "Value", PIndxRemapRange)
  PIndxRaster = outputFolder + "\\" + "P_Indx"
  PIndxReclass.save(PIndxRaster)
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Add field in the reclassified raster
  PIndxFnl = arcpy.AddField_management(PIndxRaster, "SuitIndex", "TEXT")

  # Updating landuse type information
  with arcpy.da.UpdateCursor(PIndxFnl, ['VALUE','SUITINDEX']) as pindxfile:
      for row_pindxfile in pindxfile:
          # Suitability Criteria
          if row_pindxfile[0] == 1:
             row_pindxfile[1] = "Highly Suitable Areas, (PI: 0~59)"
          elif row_pindxfile[0] == 2:
             row_pindxfile[1] = "Moderately Suitable Areas, (PI: 59~79)"
          elif row_pindxfile[0] == 3:
             row_pindxfile[1] = "Marginally Suitable Areas, (PI: 79~99)" 
          else:
             row_pindxfile[1] = "Unsuitable Areas, (PI: 100 or greater)"

          pindxfile.updateRow(row_pindxfile)
           

except:
  # Adding error massage if the script fail to run
  arcpy.AddError("Could not determine the P index. Check error messages.")
  arcpy.AddError(arcpy.GetMessages())
  # Deleting intermediate data
  arcpy.Delete_management(clpLndRaster)
  arcpy.Delete_management(lndRaster)
  arcpy.Delete_management(outSoilTestPReclass)
  arcpy.Delete_management(outSoilTestRate)
  arcpy.Delete_management(outSourceFact)
  arcpy.Delete_management(precipRFact)
  arcpy.Delete_management(IDWrFact)
  arcpy.Delete_management(prcSlope)
  arcpy.Delete_management(degSlope)
  arcpy.Delete_management(rsmplSlope)
  arcpy.Delete_management(rsmpDeglSlope)
  arcpy.Delete_management(clipDegSlope)
  arcpy.Delete_management(mFactor)
  arcpy.Delete_management(slopeLengthRaster)
  arcpy.Delete_management(clipSlope)
  arcpy.Delete_management(outRaster)
  arcpy.Delete_management(lndRaster)
  arcpy.Delete_management(fnlRFact)
  arcpy.Delete_management(kFactor)
  arcpy.Delete_management(fnlLSfact)
  arcpy.Delete_management(cFacReclass)
  arcpy.Delete_management(pFactReclass)
  arcpy.Delete_management(IntrmSoilErsn)
  arcpy.Delete_management(outFnlSoilErsn)
  arcpy.Delete_management(runoffPotential)
  arcpy.Delete_management(soilInfo)
  arcpy.Delete_management(clipNHD)
  arcpy.Delete_management(dslvClipNHD)
  arcpy.Delete_management(buff100)
  arcpy.Delete_management(buff200)
  arcpy.Delete_management(RA100)
  arcpy.Delete_management(EA200to100)
  arcpy.Delete_management(RA200to100)
  arcpy.Delete_management(buff350)
  arcpy.Delete_management(EA350to200)
  arcpy.Delete_management(RA350to200)
  arcpy.Delete_management(buff500)
  arcpy.Delete_management(EA500to350)
  arcpy.Delete_management(RA500to350)
  arcpy.Delete_management(outsideBuffer)
  arcpy.Delete_management(MergeBuffer)
  arcpy.Delete_management(contrbtDist)
  arcpy.Delete_management(outTransportSum)
  arcpy.Delete_management(outTransportFactor)
  

finally:
  try:
    # Deleting intermediate data
    arcpy.Delete_management(clpLndRaster)
    arcpy.Delete_management(lndRaster)
    arcpy.Delete_management(outSoilTestPReclass)
    arcpy.Delete_management(outSoilTestRate)
    arcpy.Delete_management(outSourceFact)
    arcpy.Delete_management(precipRFact)
    arcpy.Delete_management(IDWrFact)
    arcpy.Delete_management(prcSlope)
    arcpy.Delete_management(degSlope)
    arcpy.Delete_management(rsmplSlope)
    arcpy.Delete_management(rsmpDeglSlope)
    arcpy.Delete_management(clipDegSlope)
    arcpy.Delete_management(mFactor)
    arcpy.Delete_management(slopeLengthRaster)
    arcpy.Delete_management(clipSlope)
    arcpy.Delete_management(outRaster)
    arcpy.Delete_management(lndRaster)
    arcpy.Delete_management(fnlRFact)
    arcpy.Delete_management(kFactor)
    arcpy.Delete_management(fnlLSfact)
    arcpy.Delete_management(cFacReclass)
    arcpy.Delete_management(pFactReclass)
    arcpy.Delete_management(IntrmSoilErsn)
    arcpy.Delete_management(outFnlSoilErsn)
    arcpy.Delete_management(runoffPotential)
    arcpy.Delete_management(soilInfo)
    arcpy.Delete_management(clipNHD)
    arcpy.Delete_management(dslvClipNHD)
    arcpy.Delete_management(buff100)
    arcpy.Delete_management(buff200)
    arcpy.Delete_management(RA100)
    arcpy.Delete_management(EA200to100)
    arcpy.Delete_management(RA200to100)
    arcpy.Delete_management(buff350)
    arcpy.Delete_management(EA350to200)
    arcpy.Delete_management(RA350to200)
    arcpy.Delete_management(buff500)
    arcpy.Delete_management(EA500to350)
    arcpy.Delete_management(RA500to350)
    arcpy.Delete_management(outsideBuffer)
    arcpy.Delete_management(MergeBuffer)
    arcpy.Delete_management(contrbtDist)
    arcpy.Delete_management(outTransportSum)
    arcpy.Delete_management(outTransportFactor)

    arcpy.AddMessage("Table containing highly suitable, moderately suitable, marginally suitable, and unsuitable areas has been generated successfully in the output folder.")

  except:
    pass