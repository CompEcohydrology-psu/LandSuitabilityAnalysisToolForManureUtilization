# Python script to identify karst areas and sinkholes and create a raster
# Python version 2.7.16
# Associated with 'Karst_Area_Identification_Toolbox'
# ArcMap 10.7.1 was used to create toolbox
# Date of creation: December 10, 2019

# importing arcpy and related module
import arcpy
import math
from arcpy import env
from arcpy.sa import *
arcpy.env.overwriteOutput = True

# Defining input parameters 
inputShape1 = arcpy.GetParameterAsText(0)
inputValue = arcpy.GetParameterAsText(1)
inputShape2 = arcpy.GetParameterAsText(2)
inputShape3 = arcpy.GetParameterAsText(3)
outPath = arcpy.GetParameterAsText(4)

# Defining workspace
env.workspace = outPath

# Check criteria for merging
runCodeForInput1 = False
runCodeForInput2 = False

# Setup optional objects for merging
outputClip2 = None # Sinkhole information
outputClip3 = None # Karst information

if (not inputShape1) and (not inputShape2):
    arcpy.AddMessage("Insufficient inputs. The tool cannot identify suitable areas based on karst geology.")
    pass
    # Add Error message code or handle or continue
else:
    if inputShape1:
        runCodeForInput1 = True # We need to handle Input 1, irrespective of 2
    if inputShape2:
        runCodeForInput2 = True # We need to handle Input 2, irrespective of 1

# Task 1 (Sinkhole computation)
if runCodeForInput1:
    # Clipping the buffer
    outputClip1 = outPath + "\\" + "clipSinkholes.shp"
    clipSinkholes = arcpy.Clip_analysis(inputShape1, inputShape3, outputClip1)
    # Sinkhole buffer setup
    bufferList = []
    bufferShapeList = []

    for oid,long,lat in arcpy.da.SearchCursor("clipSinkholes.shp", ["OID@", "SHAPE@X", "SHAPE@Y"]):
        # Current multipoint's location
        XY = (long, lat)

        # Create shapefile from XY coordinate
        arcpy.CreateFeatureclass_management(outPath, "Selected_Point1.shp", "POINT", "", "", "", arcpy.SpatialReference(4326))
        with arcpy.da.InsertCursor("Selected_Point1.shp", ["SHAPE@XY"])as cursor:
            cursor.insertRow([XY])
        outName = "Selected_Point.shp"
        arcpy.Project_management("Selected_Point1.shp", outName, arcpy.SpatialReference(6347), "WGS_1984_(ITRF00)_To_NAD_1983_2011")
        
        # Making a layer with feature class
        arcpy.MakeFeatureLayer_management(outName, "BufferCenter")
        
        # Creating Buffer with the average distance

        Buff = arcpy.Buffer_analysis("BufferCenter", "Buffer_{}".format(oid), inputValue + " Meters")
                
        # Add buffer name to bufferlist
        bufferList.append(Buff)        
        bufferShapeList.append("Buffer_{}.shp".format(oid))
        
    # Merging all sinkhole buffers      
    mrgSinkBuff = arcpy.Merge_management(bufferList, outPath+"/mrgSinkBuff.shp")
        
    # Adding new field to the study area shape
    arcpy.AddField_management(mrgSinkBuff, "Source", "SHORT")
    with arcpy.da.UpdateCursor(mrgSinkBuff, ['Source']) as fillfile:
        for line_fillfile in fillfile:
            line_fillfile[0] = 4
            fillfile.updateRow(line_fillfile)
    
    # Clipping the buffer
    outputClip2 = outPath + "\\" + "clipBuffer.shp"
    clippedBuffer1 = arcpy.Clip_analysis(mrgSinkBuff, inputShape3, outputClip2)
        
    # Deleting individual sinkhole buffers
    for buffShape in bufferShapeList:
        arcpy.Delete_management(buffShape)

    # Deleting locations
    arcpy.Delete_management("Selected_Point1.shp")
    arcpy.Delete_management(outName)

# Task 2 (Karst computation)        
if runCodeForInput2:
    # Clipping karst areas
    outputClip3 = outPath + "\\" + "modKarst.shp"
    clippedKarst = arcpy.Clip_analysis(inputShape2, inputShape3, outputClip3)

    # Adding new field to the study area shape
    arcpy.AddField_management(clippedKarst, "Source", "SHORT")
    with arcpy.da.UpdateCursor(clippedKarst, ['Source']) as gapfile:
        for line_gapfile in gapfile:
            line_gapfile[0] = 2
            gapfile.updateRow(line_gapfile)

# Task 3 (adding new field to the study area shape)
arcpy.AddField_management(inputShape3, "Source", "SHORT")
with arcpy.da.UpdateCursor(inputShape3, ['Source']) as blankfile:
    for line_blankfile in blankfile:
        line_blankfile[0] = 1
        blankfile.updateRow(line_blankfile)

# Merging Protocol
objectsToMerge = [info for info in [outputClip2, outputClip3, inputShape3] if not info is None]              
Merged = arcpy.Merge_management(objectsToMerge, outPath+ "/krstCntyBuff.shp")

# Deleting field from attribute table of study area
## Buffer with new Source field already deleted
if runCodeForInput2: # Got karst info ... delete field
    arcpy.DeleteField_management(inputShape2, ["Source"])
arcpy.DeleteField_management(inputShape3, ["Source"])

# Deleting field from attribute table of study area
## Buffer with new Source field already deleted
if runCodeForInput2: # Got karst info ... delete field
    arcpy.DeleteField_management(inputShape2, ["Source"])
arcpy.DeleteField_management(inputShape3, ["Source"])

# Deleting shapefiles
arcpy.Delete_management("bufferMerged.shp")
arcpy.Delete_management("clipBuffer.shp")
arcpy.Delete_management("clipSinkholes.shp")
arcpy.Delete_management("modKarst.shp")
arcpy.Delete_management("mrgSinkBuff.shp")

# Create karst raster
output_karst = outPath + "\\" + "karst"
arcpy.FeatureToRaster_conversion(Merged, "Source", output_karst, 30)

# Adding suitability criteria field to the new karst raster
arcpy.AddField_management("karst", "SUIT_CRITERIA", "TEXT")
with arcpy.da.UpdateCursor("karst", ["VALUE","SUIT_CRITERIA"]) as reqfile:
    for row_reqfile in reqfile:
        # Suitability Criteria
        if row_reqfile[0] == 1:
           row_reqfile[1] = "Highly Suitable Areas"
           
        elif row_reqfile[0] == 2:
           row_reqfile[1] = "Moderately Suitable Areas"
           
        elif row_reqfile[0] == 3:
           row_reqfile[1] = "Less Suitable Areas"
           
        elif row_reqfile[0] == 4:
           row_reqfile[1] = "Unsuitable Areas"

        reqfile.updateRow(row_reqfile)
           
# Deleting shapefile
arcpy.Delete_management("krstCntyBuff.shp")

# Add message while complete the run
arcpy.AddMessage("Tool execution complete. The karst raster in the output folder demonstrates different types of suitable areas within the study area based on karst geology.")