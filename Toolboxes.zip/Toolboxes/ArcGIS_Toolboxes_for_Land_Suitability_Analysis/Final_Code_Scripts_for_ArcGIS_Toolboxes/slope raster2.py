# Python script to classify lands based on the slope and create a raster
# Python version 2.7.16
# Associated with 'Slope_based_Area_Classification_Toolbox'
# ArcMap 10.7.1 was used to create toolbox
# Date of creation: December 10, 2019

# importing arcpy and related module
import arcpy
import math
from arcpy import env
from arcpy.sa import *
arcpy.env.overwriteOutput = True

# Defining input parameters 

inputDemRaster = arcpy.GetParameterAsText(0)
inputStudy = arcpy.GetParameterAsText(1)
outputFolder = arcpy.GetParameterAsText(2)

# Defining workspace
env.workspace = outputFolder

try:

  # Process: Slope

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Percent slope development
  prcSlope = arcpy.gp.Slope_sa(inputDemRaster,"slp_prc","PERCENT_RISE", "1")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: Resample

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Resample of slope
  arcpy.env.extent = inputStudy
  rsmplSlope = arcpy.Resample_management(prcSlope, "slp_rsmp", "30 30", "NEAREST")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: Extract by Mask

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Mask the slope within study
  clipSlope = arcpy.gp.ExtractByMask_sa(rsmplSlope, inputStudy, "clp_Rsmp_Slp")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: Raster Calculation

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Assign grid classification by using raster calculator 
  slopeClass = arcpy.gp.RasterCalculator_sa("Con((\"clp_Rsmp_Slp\">=16.0001), 4, Con((\"clp_Rsmp_Slp\">=8.0001), 3, Con((\"clp_Rsmp_Slp\">=3.0001), 2, Con((\"clp_Rsmp_Slp\"<3.0001), 1, \"clp_Rsmp_Slp\"))))", "Slp_4Cls")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: Combine

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Combine the raster to generate attribute table
  combineSlope = Combine([slopeClass])
  outCombineSlope = outputFolder + "\\" + "cmb_Slope"
  combineSlope.save(outCombineSlope)
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Reclassification with reclassify tool 
  arcpy.CheckOutExtension("Spatial")
  finalSlopeReclass = Reclassify(combineSlope, "SLP_4CLS", RemapValue([[1,1],[2,2],[3,3],[4,4]]))
  finalSlopeRaster = outputFolder + "\\" + "fnl_Slope"
  finalSlopeReclass.save(finalSlopeRaster)
  arcpy.CheckInExtension ("Spatial")

  # Add field in the reclassified raster
  arcpy.AddField_management(finalSlopeRaster, "SuitIndex", "TEXT")

  # Updating suitability class information
  with arcpy.da.UpdateCursor(finalSlopeRaster, ['VALUE','SuitIndex']) as fnlSlopeFile:
      for row_fnlSlopeFile in fnlSlopeFile:
          # Suitability Criteria
          if row_fnlSlopeFile[0] == 1:
             row_fnlSlopeFile[1] = "Highly Suitable Areas, (0~3%)"
          elif row_fnlSlopeFile[0] == 2:
             row_fnlSlopeFile[1] = "Moderately Suitable Areas, (3~8%)"
          elif row_fnlSlopeFile[0] == 3:
             row_fnlSlopeFile[1] = "Marginally Suitable Areas, (8~16%)" 
          else:
             row_fnlSlopeFile[1] = "Unsuitable Areas, (>16%)"
             
          fnlSlopeFile.updateRow(row_fnlSlopeFile)

except:
  # Adding error massage if the script fail to run
  arcpy.AddError("Could not identify slope classes. Check error messages.")
  arcpy.AddError(arcpy.GetMessages())

  # Delete Intermediate files
  arcpy.Delete_management(prcSlope)
  arcpy.Delete_management(rsmplSlope)
  arcpy.Delete_management(clipSlope)
  arcpy.Delete_management(slopeClass)
  arcpy.Delete_management(outCombineSlope)

finally:
  try:
    # Delete field "FloodValue"
    #arcpy.DeleteField_management(inputFloodFeature, "FloodValue")
      # Delete Intermediate files
    arcpy.Delete_management(prcSlope)
    arcpy.Delete_management(rsmplSlope)
    arcpy.Delete_management(clipSlope)
    arcpy.Delete_management(slopeClass)
    arcpy.Delete_management(outCombineSlope)

    arcpy.AddMessage("Table containing highly suitable, moderately suitable, marginally suitable, and unsuitable areas has been generated successfully in the output folder.")

  except:
    pass
