# Python script to create buffers both sides of the streams  and create a raster
# Python version 2.7.16
# Associated with 'Proximity_to_Streams_Identification_Toolbox'
# ArcMap 10.7.1 was used to create toolbox
# Date of creation: December 10, 2019

# importing arcpy and related module
import arcpy
import math
from arcpy import env
from arcpy.sa import *
arcpy.env.overwriteOutput = True

# Defining input parameters 

inputNHDFeature = arcpy.GetParameterAsText(0)
inputBufferVal = arcpy.GetParameterAsText(1)
inputStudy = arcpy.GetParameterAsText (2)
outputFolder = arcpy.GetParameterAsText(3)

# Defining workspace
env.workspace = outputFolder

try:
   
    # Process: flood layer clipping
    clipNHD1 = arcpy.Clip_analysis(inputNHDFeature, inputStudy, "clpNHD.shp")

    # Process: Dissolve
    DslvStrm = arcpy.Dissolve_management(clipNHD1, "dslvStrm.shp", "", "", "MULTI_PART", "DISSOLVE_LINES")

    # Process: Buffer
    buffNHD = arcpy.Buffer_analysis(DslvStrm, "buffNHD.shp", inputBufferVal + " Meters", "FULL", "ROUND", "NONE", "", "PLANAR")


    # Adding field to the dissolved stream buffer 
    arcpy.AddField_management(buffNHD, "StrmID", "SHORT")

    # Updating the field value
    with arcpy.da.UpdateCursor(buffNHD, ['StrmID']) as strmfile:
        for row_strmfile in strmfile:
            # Suitability Criteria
            row_strmfile[0] = 2           
            strmfile.updateRow(row_strmfile)

    # Process: Flood Layer Clipping
    clipNHD2 = arcpy.Clip_analysis(buffNHD, inputStudy, "bffNHDstdy.shp")

    # Process: Dissolve study area
    DslvStdy = arcpy.Dissolve_management(inputStudy, "dslvStdy.shp", "", "", "MULTI_PART", "DISSOLVE_LINES")

    # Adding field to the dissolved stream buffer 
    arcpy.AddField_management(DslvStdy, "StrmID", "SHORT")

    # Updating the field value
    with arcpy.da.UpdateCursor(DslvStdy, ['StrmID']) as stdyfile:
        for row_stdyfile in stdyfile:
            # Suitability Criteria
            row_stdyfile[0] = 1           
            stdyfile.updateRow(row_stdyfile)

    # Merging both stream buffer and study area
    mrgStrmBuff = arcpy.Merge_management(["bffNHDstdy.shp","dslvStdy.shp"], "mrgBuffStdy.shp")

    # Define study area extent for raster      
    arcpy.env.extent = inputStudy

    # Converting merged stream raster
    strmRaster = arcpy.FeatureToRaster_conversion(mrgStrmBuff, "StrmID", "StrmPrxmty", 30)

    # Add field in the merged raster
    arcpy.AddField_management(strmRaster, "SuitIndex", "TEXT")

    # Updating landuse type information
    with arcpy.da.UpdateCursor(strmRaster, ['VALUE','SuitIndex']) as strmfile:
        for row_strmfile in strmfile:
            # Suitability Criteria
            if row_strmfile[0] == 1:
               row_strmfile[1] = "Suitable Areas"
            else:
               row_strmfile[1] = "Unsuitable Areas"
               
            strmfile.updateRow(row_strmfile)


except:
     # Adding error massage if the script fail to run
    arcpy.AddError("Could not identify proximity to streams buffer. Check error messages.")
    arcpy.AddError(arcpy.GetMessages())
    # Deleting temporary data
    arcpy.Delete_management(clipNHD1)
    arcpy.Delete_management(DslvStrm)
    arcpy.Delete_management(buffNHD)
    arcpy.Delete_management(clipNHD2)
    arcpy.Delete_management(DslvStdy)
    arcpy.Delete_management(mrgStrmBuff)
    
finally:
    try:
        # Deleting temporary data
        arcpy.Delete_management(clipNHD1)
        arcpy.Delete_management(DslvStrm)
        arcpy.Delete_management(buffNHD)
        arcpy.Delete_management(clipNHD2)
        arcpy.Delete_management(DslvStdy)
        arcpy.Delete_management(mrgStrmBuff)
    except:
        pass