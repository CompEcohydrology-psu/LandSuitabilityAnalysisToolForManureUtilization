# Python script to identify shallow soils and create a raster
# Python version 2.7.16
# Associated with 'Shallow_Soil_Identification_Toolbox'
# ArcMap 10.7.1 was used to create toolbox
# Date of creation: December 10, 2019

# importing arcpy and related module
import arcpy
import math
from arcpy import env
from arcpy.sa import *
arcpy.env.overwriteOutput = True

# Defining input parameters 

inputSoilFeature = arcpy.GetParameterAsText(0)
inputStudy = arcpy.GetParameterAsText(1)
outputFolder = arcpy.GetParameterAsText(2)

# Defining workspace
env.workspace = outputFolder

try:

  # Process: Flood Layer Clipping
  clipShallow = arcpy.Clip_analysis(inputSoilFeature, inputStudy, "clpShallow.shp")

  # where only highly and moderately suitable areas are suggested for manure utilization
  arcpy.AddField_management(clipShallow, "Shallow", "SHORT")

  with arcpy.da.UpdateCursor(clipShallow, ['brckdepmin','Shallow']) as shallowfile:
      for row_shallowfile in shallowfile:
          # Suitability Criteria         
          if row_shallowfile[0] < 50:
             row_shallowfile[1] = 2
             
          else:
             row_shallowfile[1] = 1
             
          shallowfile.updateRow(row_shallowfile)

  # Define study area extent for raster      
  arcpy.env.extent = inputStudy
   
  # Execute FeatureToRaster
  ShallowFinal = arcpy.FeatureToRaster_conversion(clipShallow, "Shallow", "ShallowFnl", 30)
  arcpy.AddField_management(ShallowFinal, "SuitIndx", "TEXT")

  with arcpy.da.UpdateCursor(ShallowFinal, ['VALUE','SuitIndx']) as shlwRasterFile:
      for row_shlwRasterFile in shlwRasterFile:
          # Suitability Criteria
          if row_shlwRasterFile[0] == 1:
             row_shlwRasterFile[1] = "Suitable Areas"  
          else:
             row_shlwRasterFile[1] = "Marginally Suitable Areas"
             
          shlwRasterFile.updateRow(row_shlwRasterFile)


except:
  # Adding error massage if the script fail to run
  arcpy.AddError("Could not identify shallow soils. Check error messages.")
  arcpy.AddError(arcpy.GetMessages())
  # Delete field shallow soils
  arcpy.Delete_management(clipShallow)
  
finally:
  try:
    # Delete field shallow soils
    arcpy.Delete_management(clipShallow)
  except:
    pass