# Python script to identify area based on leaching index classification and create rasters
# Python version 2.7.16
# Associated with 'Leaching_Index_based_Area_Classification_Toolbox'
# ArcMap 10.7.1 was used to create toolbox
# Date of creation: December 10, 2019

#importing arcpy and related module
import arcpy
import math
from arcpy import env
from arcpy.sa import *
arcpy.env.overwriteOutput = True

# Defining input parameters 
#inputSoilFeature = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs/Soil_Proj.shp"
inputSoilFeature = arcpy.GetParameterAsText(0)
#inputPrecipFeature = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs/Station_all_proj.shp"
inputPrecipFeature = arcpy.GetParameterAsText(1)
#inputStudy = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs/stdy3conts2.shp"
inputStudy = arcpy.GetParameterAsText(2)
#outputFolder = "C:/GKS/Land Suitability Framework_new/Output Folder"
outputFolder = arcpy.GetParameterAsText(3)

# Defining workspace
env.workspace = outputFolder

try:
  
  # Process: Hydrologic Group Feature Clipping
  clipHydGrp = arcpy.Clip_analysis(inputSoilFeature, inputStudy, "clpHydGrp.shp")

  # where only highly and moderately suitable areas are suggested for manure utilization
  arcpy.AddField_management(clipHydGrp, "HydGrpVal", "SHORT")

  with arcpy.da.UpdateCursor(clipHydGrp, ['SolHydGrp','HydGrpVal']) as hydGrpFile:
      for row_hydGrpFile in hydGrpFile:
          # Suitability Criteria         
          if row_hydGrpFile[0] == 'A':
             row_hydGrpFile[1] = 1
          elif row_hydGrpFile[0] == 'B':
             row_hydGrpFile[1] = 2
          elif row_hydGrpFile[0] == 'C':
             row_hydGrpFile[1] = 3
          else:
             row_hydGrpFile[1] = 4
             
          hydGrpFile.updateRow(row_hydGrpFile)

  # Process: Feature to Raster Conservation

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Input extent
  arcpy.env.extent = inputStudy
  # Converting soil hydrologic group feature to a new raster 
  hydGrpRast = arcpy.FeatureToRaster_conversion(clipHydGrp, "HydGrpVal", "hydgrp", "30")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Delete hydgrp files
  arcpy.Delete_management(clipHydGrp)

  # Functions for calculating Percolation Index
  # Process: Inverse Distance Weighting (IDW) 1

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Input extent
  arcpy.env.extent = inputStudy
  # Apply Inverse Distance Weighting function to the respective precipitation station
  annualPrecip = arcpy.gp.Idw_sa(inputPrecipFeature, "Pcp_Anl_in", "Anl_pcp", "30", "2", "VARIABLE 12", "")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: Extract by Mask 1

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Mask the annual precipitation within study
  maskAnlPrecip = arcpy.gp.ExtractByMask_sa(annualPrecip, inputStudy, "anl_pcp_msk")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: Raster calculation 1

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Creat interim raster by multiplying hydrologic soil group with 100
  outHydGrp100 = outputFolder + "\\" + "hydgrp100"
  multiHydGrp = Raster("hydgrp") * 100
  multiHydGrp.save(outHydGrp100)
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: Raster calculation 2

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Creat interim raster with factored hydrologic soil group and annual precipitation within study
  outHydGrpAnlPcp = outputFolder + "\\" + "hyd_apcp"
  hydGrpAnlPcp = Raster("hydgrp100") + Raster("anl_pcp_msk")
  hydGrpAnlPcp.save(outHydGrpAnlPcp)
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: Percolation index Raster calculation

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Creating percolation index raster within the study area
  outPercIndex = outputFolder + "\\" + "perc_indx"
  # Percolation index calculation by using precipitation and hydrologic soil group 
  percIndex = Con(Raster(outHydGrpAnlPcp) < 200, Power(((Raster(outHydGrpAnlPcp)-100)-10.28),2)/((Raster(outHydGrpAnlPcp)-100)+15.43), Con((Raster(outHydGrpAnlPcp) >= 200) & (Raster(outHydGrpAnlPcp) < 300), Power(((Raster(outHydGrpAnlPcp)-200)-15.05),2)/((Raster(outHydGrpAnlPcp)-200)+22.57), Con((Raster(outHydGrpAnlPcp) >= 300) & (Raster(outHydGrpAnlPcp) < 400), Power(((Raster(outHydGrpAnlPcp)-300)-19.53),2)/((Raster(outHydGrpAnlPcp)-300)+29.29), Con(Raster(outHydGrpAnlPcp) >= 400, Power(((Raster(outHydGrpAnlPcp)-400)-22.67),2)/((Raster(outHydGrpAnlPcp)-400)+34.00)))))
  percIndex.save(outPercIndex)


  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Functions for calculating Seasonal Index
  # Process: Inverse Distance Weighting (IDW) 2

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Input extent
  arcpy.env.extent = inputStudy
  # Apply Inverse Distance Weighting function to the respective precipitation station (previously calculated seasonal precipitation)
  seasonalPrecip = arcpy.gp.Idw_sa(inputPrecipFeature, "Pw_in", "ssnl_pcp", "30", "2", "VARIABLE 12", "")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: Extract by Mask 2

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Mask the seasonal precipitation within study
  maskSSnlPrecip = arcpy.gp.ExtractByMask_sa(seasonalPrecip, inputStudy, "ssnl_pcp_msk")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: Raster calculation 4

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Create interim raster within study {2 *(Pw/Pa)}
  outSsnlPcp = outputFolder + "\\" + "intrm_spcp"
  SsnlPcp = (Raster("ssnl_pcp_msk") / Raster("anl_pcp_msk"))* 2
  SsnlPcp.save(outSsnlPcp)
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: Raster calculation 5

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Calculating percolation index
  SsnlIndex = arcpy.gp.RasterCalculator_sa("Power(\"intrm_spcp\",0.3333)", "ssnl_indx")
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Process: Raster calculation 6

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Create leaching index raster within study 
  outLchIndx = outputFolder + "\\" + "lch_indx_val"
  LchIndx = Raster("perc_indx.tif") * Raster("ssnl_indx")
  LchIndx.save(outLchIndx)
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Leaching Index reclassification to assign suitability criteria
  # Reclassification with reclassify tool

  # Check out the ArcGIS Spatial Analyst extension license
  arcpy.CheckOutExtension("Spatial")
  # Create a range for reclassification
  leachRemapRange = RemapRange([[0, 5, 1], [5, 10, 2], [10, 20, 3],[20, 500, 4]])
  # Reclassification of leaching index to create suitability index by using remap range
  lchIndxReclass = Reclassify(LchIndx, "Value", leachRemapRange)
  leachRaster = outputFolder + "\\" + "Lch_Indx"
  lchIndxReclass.save(leachRaster)
  # Check in the ArcGIS Spatial Analyst extension license
  arcpy.CheckInExtension ("Spatial")

  # Add field in the reclassified raster
  lchIndxFnl = arcpy.AddField_management(lchIndxReclass, "SuitIndex", "TEXT")

  # Updating landuse type information
  with arcpy.da.UpdateCursor(lchIndxFnl, ['VALUE','SuitIndex']) as leachfile:
      for row_leachfile in leachfile:
          # Suitability Criteria
          if row_leachfile[0] == 1:
             row_leachfile[1] = "Highly Suitable Areas, (LI: 1~5)"
          elif row_leachfile[0] == 2:
             row_leachfile[1] = "Moderately Suitable Areas, (LI: 5~10)"
          elif row_leachfile[0] == 3:
             row_leachfile[1] = "Marginally Suitable Areas, (LI: 10~20)" 
          else:
             row_leachfile[1] = "Unsuitable Areas, (LI: >20)"
             
          leachfile.updateRow(row_leachfile)


except:

  # Adding error massage if the script fail to run
  arcpy.AddError("Could not identify NLI classes. Check error messages.")
  arcpy.AddError(arcpy.GetMessages())

  # Delete Temporary files
  arcpy.Delete_management(hydGrpRast)
  arcpy.Delete_management(annualPrecip)
  arcpy.Delete_management(maskAnlPrecip)
  arcpy.Delete_management(multiHydGrp)
  arcpy.Delete_management(hydGrpAnlPcp)
  arcpy.Delete_management(percIndex)
  arcpy.Delete_management(seasonalPrecip)
  arcpy.Delete_management(maskSSnlPrecip)
  arcpy.Delete_management(SsnlPcp)
  arcpy.Delete_management(SsnlIndex)
  
finally:
  try:
    # Delete Temporary files
    arcpy.Delete_management(hydGrpRast)
    arcpy.Delete_management(annualPrecip)
    arcpy.Delete_management(maskAnlPrecip)
    arcpy.Delete_management(multiHydGrp)
    arcpy.Delete_management(hydGrpAnlPcp)
    arcpy.Delete_management(percIndex)
    arcpy.Delete_management(seasonalPrecip)
    arcpy.Delete_management(maskSSnlPrecip)
    arcpy.Delete_management(SsnlPcp)
    arcpy.Delete_management(SsnlIndex)

    arcpy.AddMessage("Table containing highly suitable, moderately suitable, marginally suitable, and unsuitable areas has been generated successfully in the output folder.")


  except:
    pass
