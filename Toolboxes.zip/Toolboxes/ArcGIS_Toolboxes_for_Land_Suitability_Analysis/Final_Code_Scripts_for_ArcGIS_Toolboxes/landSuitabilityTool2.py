# Python script to identify the final land suitability raster
# Python version 2.7.16
# Associated with 'Final_Land_Suitability_Analysis_Toolbox'
# ArcMap 10.7.1 was used to create toolbox
# Date of creation: December 10, 2019

# importing arcpy and related module
import arcpy
import math
from arcpy import env
from arcpy.sa import *
arcpy.env.overwriteOutput = True


# Defining input parameters 
# inputPotentialArea = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs for final land suitability code/Raster/Potential Areas/potentialarea"
inputPotentialArea = arcpy.GetParameterAsText(0)
# inputFloodArea = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs for final land suitability code/Raster/Flood Areas/fldfnl"
inputFloodArea =arcpy.GetParameterAsText(1)
# inputProximityStream = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs for final land suitability code/Raster/Proximity to Streams/strmprxmty"
inputProximityStream = arcpy.GetParameterAsText(2)
# inputShallowSoil = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs for final land suitability code/Raster/Shallow Soil Areas/shallowfnl"
inputShallowSoil = arcpy.GetParameterAsText(3)

inputKarst = arcpy.GetParameterAsText(4)
# inputSlope = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs for final land suitability code/Raster/Slope Areas/fnl_slope"
inputSlope = arcpy.GetParameterAsText(5)
# inputLeach = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs for final land suitability code/Raster/Leaching Index/lch_indx"
inputLeach = arcpy.GetParameterAsText(6)
# inputPIindex = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Inputs for final land suitability code/Raster/P Index/p_indx2"
inputPIindex = arcpy.GetParameterAsText(7)

#inputStudy = "C:/GKS/Land Suitability Framework_new/Curent Workspace/Input_kiskimites/Kiskiminetas_prj.shp"
inputStudy= arcpy.GetParameterAsText(8)

#outputFolder = "C:/GKS/Land Suitability Framework_new/Output Folder"
outputFolder = arcpy.GetParameterAsText(9)


# Defining workspace
env.workspace = outputFolder

try:
	
	# Raster calculation for potential area and floodplain combination
	# Check out the ArcGIS Spatial Analyst extension license
	arcpy.CheckOutExtension("Spatial")
	# Create combined raster of potential area and floodplain within study 
	outPtnFld = outputFolder + "\\" + "ptn_Fld"
	ptnFld = Raster(inputPotentialArea)* 10 + Raster(inputFloodArea)
	ptnFld.save(outPtnFld)
	# Check in the ArcGIS Spatial Analyst extension license
	arcpy.CheckInExtension ("Spatial")

	# Check out the ArcGIS Spatial Analyst extension license 
	arcpy.CheckOutExtension("Spatial")
	# Reclassify combined potential and flood raster
	ptnFldReclass = Reclassify(ptnFld, "VALUE", RemapRange([[11,1],[12,2],[21,2],[22,2]]))
	ptnFldRaster = outputFolder + "\\" + "ptnFld_rcl"
	ptnFldReclass.save(ptnFldRaster)
	# Check in the ArcGIS Spatial Analyst extension license
	arcpy.CheckInExtension ("Spatial")


	# Raster calculation for potential area, floodplain, and proximity to stream combination
	# Check out the ArcGIS Spatial Analyst extension license
	arcpy.CheckOutExtension("Spatial")
	# Create combined raster of potential area, floodplain, and proximity to stream within study 
	outPtnFldPrxSrm = outputFolder + "\\" + "ptFdSn"
	ptnFldPrxSrm = Raster(ptnFldRaster)* 10 + Raster(inputProximityStream)
	ptnFldPrxSrm.save(outPtnFldPrxSrm)
	# Check in the ArcGIS Spatial Analyst extension license
	arcpy.CheckInExtension ("Spatial")


	# Check out the ArcGIS Spatial Analyst extension license 
	arcpy.CheckOutExtension("Spatial")
	# Reclassify combined potential, flood raster and proximity to stream combination
	ptnFldPrxSrmReclass = Reclassify(outPtnFldPrxSrm, "VALUE", RemapRange([[11,1],[12,2],[21,2],[22,2]]))
	ptnFldPrxSrmRaster = outputFolder + "\\" + "ptFdSn_rcl"
	ptnFldPrxSrmReclass.save(ptnFldPrxSrmRaster)
	# Check in the ArcGIS Spatial Analyst extension license
	arcpy.CheckInExtension ("Spatial")


	# Raster calculation for potential area, floodplain, proximity to stream, and shallow soils combination
	# Check out the ArcGIS Spatial Analyst extension license
	arcpy.CheckOutExtension("Spatial")
	# Create combined raster of potential area, floodplain, proximity to stream combination, and shallow soils within study 
	outPtFdSnSw = outputFolder + "\\" + "ptFdSnSw"
	ptFdSnSw = Raster(ptnFldPrxSrmRaster)* 10 + Raster(inputShallowSoil)
	ptFdSnSw.save(outPtFdSnSw)
	# Check in the ArcGIS Spatial Analyst extension license
	arcpy.CheckInExtension ("Spatial")


	# Check out the ArcGIS Spatial Analyst extension license 
	arcpy.CheckOutExtension("Spatial")
	# Reclassify combinedpotential area, floodplain, proximity to stream combination, and shallow soils combination
	ptFdSnSwReclass = Reclassify(outPtFdSnSw, "VALUE", RemapRange([[11,1],[12,3],[21,4],[22,4]]))
	ptFdSnSwRaster = outputFolder + "\\" + "ptFdSnSw_r"
	ptFdSnSwReclass.save(ptFdSnSwRaster)
	# Check in the ArcGIS Spatial Analyst extension license
	arcpy.CheckInExtension ("Spatial")


	# Raster calculation for potential area, floodplain, proximity to stream, shallow soils, and slope combination
	# Check out the ArcGIS Spatial Analyst extension license
	arcpy.CheckOutExtension("Spatial")
	# Create combined raster of potential area, floodplain, proximity to stream and shallow soils combination within study 
	outPtFdSnSwSL = outputFolder + "\\" + "ptFdSnSwSl"
	ptFdSnSwSl = Raster(ptFdSnSwRaster)* 10 + Raster(inputSlope)
	ptFdSnSwSl.save(outPtFdSnSwSL)
	# Check in the ArcGIS Spatial Analyst extension license
	arcpy.CheckInExtension ("Spatial")


	# Check out the ArcGIS Spatial Analyst extension license 
	arcpy.CheckOutExtension("Spatial")
	# Reclassify combinedpotential area, floodplain, proximity to stream combination, and shallow soils combination
	ptFdSnSwSlReclass = Reclassify(outPtFdSnSwSL, "VALUE", RemapRange([[11,1],[12,2],[13,3],[14,4],[31,3],[32,3],[33,3],[34,4],[41,4],[42,4],[43,4],[44,4]]))
	ptFdSnSwSlRaster = outputFolder + "\\" + "ptFdSnSwSl_r"
	ptFdSnSwSlReclass.save(ptFdSnSwSlRaster)
	# Check in the ArcGIS Spatial Analyst extension license
	arcpy.CheckInExtension ("Spatial")


	# Raster calculation for potential area, floodplain, proximity to stream, shallow soils, slope, and LI combination
	# Check out the ArcGIS Spatial Analyst extension license
	arcpy.CheckOutExtension("Spatial")
	# Create combined raster of potential area, floodplain, proximity to stream shallow soils, slope, and LI combination within study 
	outPtFdSnSwSLLi = outputFolder + "\\" + "FdSnSwSlLi"
	ptFdSnSwSlLi = Raster(ptFdSnSwSlRaster)* 10 + Raster(inputLeach)
	ptFdSnSwSlLi.save(outPtFdSnSwSLLi)
	# Check in the ArcGIS Spatial Analyst extension license
	arcpy.CheckInExtension ("Spatial")


	# Check out the ArcGIS Spatial Analyst extension license 
	arcpy.CheckOutExtension("Spatial")
	# Reclassify combinedpotential area, floodplain, proximity to stream, shallow soils, slope, and LI combination
	ptFdSnSwSlLiReclass = Reclassify(outPtFdSnSwSLLi, "VALUE", RemapRange([[11,1],[12,2],[13,3],[14,4],[21,2],[22,2],[23,3],[24,4],[31,3],[32,3],[33,3],[34,4],[41,4],[42,4],[43,4],[44,4]]))
	ptFdSnSwSlLiRaster = outputFolder + "\\" + "FdSnSwSlLi_r"
	ptFdSnSwSlLiReclass.save(ptFdSnSwSlLiRaster)
	# Check in the ArcGIS Spatial Analyst extension license
	arcpy.CheckInExtension ("Spatial")


	# Raster calculation for potential area, floodplain, proximity to stream, shallow soils, slope, LI, and PI combination
	# Check out the ArcGIS Spatial Analyst extension license
	arcpy.CheckOutExtension("Spatial")
	# Create combined raster of potential area, floodplain, proximity to stream shallow soils, slope, LI, and PI combination within study 
	outPtFdSnSwSLLiPi = outputFolder + "\\" + "FdSnSwSlLiPi"
	ptFdSnSwSlLiPi = Raster(ptFdSnSwSlLiRaster)* 10 + Raster(inputPIindex)
	ptFdSnSwSlLiPi.save(outPtFdSnSwSLLiPi)
	# Check in the ArcGIS Spatial Analyst extension license
	arcpy.CheckInExtension ("Spatial")



	# Check out the ArcGIS Spatial Analyst extension license 
	arcpy.CheckOutExtension("Spatial")
	# Reclassify combinedpotential area, floodplain, proximity to stream, shallow soils, slope, and LI combination
	ptFdSnSwSlLiPiReclass = Reclassify(outPtFdSnSwSLLiPi, "VALUE", RemapRange([[11,1],[12,2],[13,3],[14,4],[21,2],[22,2],[23,3],[24,4],[31,3],[32,3],[33,3],[34,4],[41,4],[42,4],[43,4],[44,4]]))
	ptFdSnSwSlLiPiRaster = outputFolder + "\\" + "fnl_suit"
	ptFdSnSwSlLiPiReclass.save(ptFdSnSwSlLiPiRaster)
	# Check in the ArcGIS Spatial Analyst extension license
	arcpy.CheckInExtension ("Spatial")


	if inputKarst == '':
		# Add field in the reclassified raster
		SuitFnl = arcpy.AddField_management(ptFdSnSwSlLiPiReclass, "SuitIndex", "TEXT")
	else:
		# do stuff related to inputKarst
		# raster calculation on karst result
		# Check out the ArcGIS Spatial Analyst extension license
		arcpy.CheckOutExtension("Spatial")
		# Create combined raster of potential area, floodplain, proximity to stream shallow soils, slope, LI, PI, Karst combination within study 
		outPtFdSnSwSLLiPiKr = outputFolder + "\\" + "FdSnSwSlLiPiK"
		ptFdSnSwSlLiPiK = Raster(ptFdSnSwSlLiPiRaster)* 10 + Raster(inputKarst)
		ptFdSnSwSlLiPiK.save(outPtFdSnSwSLLiPiKr)
		# Check in the ArcGIS Spatial Analyst extension license
		arcpy.CheckInExtension ("Spatial")


		# Check out the ArcGIS Spatial Analyst extension license 
		arcpy.CheckOutExtension("Spatial")
		# Reclassify combinedpotential area, floodplain, proximity to stream, shallow soils, slope, and LI combination
		ptFdSnSwSlLiPiKrReclass = Reclassify(outPtFdSnSwSLLiPiKr, "VALUE", RemapRange([[11,1],[12,2],[13,3],[14,4],[21,2],[22,2],[23,3],[24,4],[31,3],[32,3],[33,3],[34,4],[41,4],[42,4],[43,4],[44,4]]))
		ptFdSnSwSlLiPiKrRaster = outputFolder + "\\" + "fnl_suit"
		ptFdSnSwSlLiPiKrReclass.save(ptFdSnSwSlLiPiKrRaster)
		# Check in the ArcGIS Spatial Analyst extension license
		arcpy.CheckInExtension ("Spatial")


		# Add field in the reclassified raster
		SuitFnl = arcpy.AddField_management(ptFdSnSwSlLiPiKrRaster, "SuitIndex", "TEXT")

		

	# Updating landuse type information
	with arcpy.da.UpdateCursor(SuitFnl, ['VALUE','SUITINDEX']) as suitfile:
	    for row_suitfile in suitfile:
	        # Suitability Criteria
	        if row_suitfile[0] == 1:
	           row_suitfile[1] = "Integrated Highly Suitable Areas (iHSA)"
	        elif row_suitfile[0] == 2:
	           row_suitfile[1] = "Integrated Moderately Suitable Areas (iMdSA)"
	        elif row_suitfile[0] == 3:
	           row_suitfile[1] = "Integrated Marginally Suitable Areas (iMgSA)" 
	        else:
	           row_suitfile[1] = "Integrated Unsuitable Areas (iUA)"

	        suitfile.updateRow(row_suitfile)


except:
	try:
		# Adding error massage if the script fail to run
		arcpy.AddError("Could not determine the final suitability map. Check error messages.")
		arcpy.AddError(arcpy.GetMessages())

		# Delete Intermediate files
		arcpy.Delete_management(outPtnFld)
		arcpy.Delete_management(ptnFldRaster)
		arcpy.Delete_management(outPtnFldPrxSrm)
		arcpy.Delete_management(ptnFldPrxSrmRaster)
		arcpy.Delete_management(outPtFdSnSw)
		arcpy.Delete_management(ptFdSnSwRaster)
		arcpy.Delete_management(outPtFdSnSwSL)
		arcpy.Delete_management(ptFdSnSwSlRaster)
		arcpy.Delete_management(outPtFdSnSwSLLi)
		arcpy.Delete_management(ptFdSnSwSlLiRaster)
		arcpy.Delete_management(outPtFdSnSwSLLiPi)
		arcpy.Delete_management(outPtFdSnSwSLLiPiKr)
	except:
		pass
	
finally:
	try:
		# Delete Intermediate files
		arcpy.Delete_management(outPtnFld)
		arcpy.Delete_management(ptnFldRaster)
		arcpy.Delete_management(outPtnFldPrxSrm)
		arcpy.Delete_management(ptnFldPrxSrmRaster)
		arcpy.Delete_management(outPtFdSnSw)
		arcpy.Delete_management(ptFdSnSwRaster)
		arcpy.Delete_management(outPtFdSnSwSL)
		arcpy.Delete_management(ptFdSnSwSlRaster)
		arcpy.Delete_management(outPtFdSnSwSLLi)
		arcpy.Delete_management(ptFdSnSwSlLiRaster)
		arcpy.Delete_management(outPtFdSnSwSLLiPi)
		arcpy.Delete_management(outPtFdSnSwSLLiPiKr)
	except:
		pass