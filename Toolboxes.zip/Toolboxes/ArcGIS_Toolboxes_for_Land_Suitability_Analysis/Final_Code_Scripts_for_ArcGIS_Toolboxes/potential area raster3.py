# Python script to identify potential areas and create rasters
# Python version 2.7.16
# Associated with 'Potential_Area_Identification_Toolbox'
# ArcMap 10.7.1 was used to create toolbox
# Date of creation: December 10, 2019

# importing arcpy and related module
import arcpy
import math
from arcpy import env
from arcpy.sa import *
arcpy.env.overwriteOutput = True


# Defining input parameters 
inputLndUseRaster = arcpy.GetParameterAsText(0)
inRemapFile = arcpy.GetParameterAsText(1)
inputStudy = arcpy.GetParameterAsText(2)
outputFolder = arcpy.GetParameterAsText(3)

# Defining workspace
env.workspace = outputFolder


try:
  
  # Define study area extent for raster      
  #arcpy.env.extent = inputStudy

  # Extracting and saving raster
  arcpy.CheckOutExtension("Spatial")
  outExtractByMask = ExtractByMask(inputLndUseRaster, inputStudy)
  clpLndRaster = outputFolder + "\\" + "ClpdLndUse"
  outExtractByMask.save(clpLndRaster)
  arcpy.CheckInExtension ("Spatial")

  # Landuse reclassification for broader landuse classes
  # Reclassification with reclassify tool 
  arcpy.CheckOutExtension("Spatial")
  lndReclass = ReclassByASCIIFile(clpLndRaster, inRemapFile)
  #lndReclass = Reclassify(outRaster, "Value", RemapValue([[0,4],[1,1],[2,1],[3,1],[4,1],[5,1],[6,4],[10,1],[11,1],[12,1],[13,1],[14,1],[21,1],[22,1],[23,1],[24,1],[25,1],[26,1],[27,1],[28,1],[29,1],[30,1],[31,1],[32,1],[33,1],[34,1],[35,1],[36,2],[37,2],[38,4],[39,1],[41,1],[42,4],[43,4],[44,1],[45,1],[46,1],[47,4],[48,4],[49,1],[50,4],[51,4],[52,1],[53,4],[54,4],[55,4],[56,4],[57,1],[58,2],[59,2],[60,2],[61,3],[62,2],[63,4],[64,4],[65,3],[66,4],[67,4],[68,4],[69,4],[70,4],[71,4],[72,4],[74,4],[75,4],[76,4],[77,4],[81,4],[82,4],[83,4],[87,4],[88,4],[92,4],[111,4],[112,4],[121,4],[122,4],[123,4],[124,4],[131,3],[141,4],[142,4],[143,4],[152,4],[176,2],[190,4],[195,4],[204,4],[205,1],[206,4],[207,4],[208,4],[209,4],[210,4],[211,4],[212,4],[213,4],[214,4],[215,4],[216,4],[217,4],[218,4],[219,4],[220,4],[221,4],[222,4],[223,4],[224,1],[225,1],[226,1],[227,1],[229,4],[230,1],[231,4],[232,1],[233,1],[234,1],[235,1],[236,1],[237,1],[238,1],[239,1],[240,1],[241,1],[242,4],[243,4],[244,4],[245,1],[246,1],[247,1],[248,4],[249,4],[250,4],[254,1]]))
  lndRaster = outputFolder + "\\" + "RclLandUses"
  lndReclass.save(lndRaster)
  arcpy.CheckInExtension ("Spatial")

  # Add field in the reclassified raster
  arcpy.AddField_management(lndRaster, "LandType", "TEXT")

  # Updating landuse type information
  with arcpy.da.UpdateCursor(lndRaster, ['VALUE','LandType']) as lndtypefile:
      for row_lndtypefile in lndtypefile:
          # Suitability Criteria
          if row_lndtypefile[0] == 1:
             row_lndtypefile[1] = "Row Croplands"
          elif row_lndtypefile[0] == 2:
             row_lndtypefile[1] = "Forage Lands"
          elif row_lndtypefile[0] == 3:
             row_lndtypefile[1] = "Currently Unutilized Non-Forest Lands" 
          else:
             row_lndtypefile[1] = "Excluded Areas"
             
          lndtypefile.updateRow(row_lndtypefile)

  # For potential raster

  # Landuse reclassification with reclassify tool to categorize into broader landuse
  arcpy.CheckOutExtension("Spatial")
  potReclass = Reclassify(lndRaster, "Value", RemapValue([[1,1],[2,1],[3,1],[4,2]]))
  potRaster = outputFolder + "\\" + "PotentialArea"
  potReclass.save(potRaster)
  arcpy.CheckInExtension ("Spatial")

  # Add field in the reclassified raster
  arcpy.AddField_management(potReclass, "SuitIndex", "TEXT")

  # Updating landuse type information
  with arcpy.da.UpdateCursor(potRaster, ['VALUE','SuitIndex']) as potfile:
      for row_potfile in potfile:
          # Suitability Criteria
          if row_potfile[0] == 1:
             row_potfile[1] = "Potential Areas"
          else:
             row_potfile[1] = "Excluded Areas"
             
          potfile.updateRow(row_potfile)


except:
  # Adding error massage if the script fail to run
  arcpy.AddError("Could not identify potential areas. Check error messages.")
  arcpy.AddError(arcpy.GetMessages())

  # Delete Temporary files
  arcpy.Delete_management(clpLndRaster)

finally:
  try:
    # Delete Temporary files
    arcpy.Delete_management(clpLndRaster)

  except:
    pass