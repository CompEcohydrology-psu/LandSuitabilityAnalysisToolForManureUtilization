# Python script to identify floodplains and create a floodplains raster
# Python version 2.7.16
# Associated with 'Floodplains_Identification_Toolbox'
# ArcMap 10.7.1 was used to create toolbox
# Date of creation: December 10, 2019

# importing arcpy and related module
import arcpy
import math
from arcpy import env
from arcpy.sa import *
arcpy.env.overwriteOutput = True

# Defining input parameters 

inputFloodFeature = arcpy.GetParameterAsText(0)
inputStudy = arcpy.GetParameterAsText(1)
outputFolder = arcpy.GetParameterAsText(2)

# Defining workspace
env.workspace = outputFolder

try:

  # Process: Flood Layer Clipping
  clipFlood = arcpy.Clip_analysis(inputFloodFeature, inputStudy, "clpFld1.shp")

  # Process: Updating Field to the Clipped Flood Layer

  # where only highly and moderately suitable areas are suggested for manure utilization
  #arcpy.AddField_management(inputFloodFeature, "FloodValue", "SHORT")
  arcpy.AddField_management(clipFlood, "FloodValue", "SHORT")

  #with arcpy.da.UpdateCursor(inputFloodFeature, ['FLD_ZONE','FloodValue']) as reqfile:
  with arcpy.da.UpdateCursor(clipFlood, ['FLD_ZONE','FloodValue']) as reqfile:
      for row_reqfile in reqfile:
          # Suitability Criteria
          if row_reqfile[0] in ['B', 'C', 'X']:
             row_reqfile[1] = 1  
          else:
             row_reqfile[1] = 2
             
          reqfile.updateRow(row_reqfile)

  # Define study area extent for raster      
  arcpy.env.extent = inputStudy
   
  # Execute FeatureToRaster
  #FloodFinal = arcpy.FeatureToRaster_conversion(inputFloodFeature, "FloodValue", "FldFnl", 30)
  FloodFinal = arcpy.FeatureToRaster_conversion(clipFlood, "FloodValue", "FldFnl", 30)
  arcpy.AddField_management(FloodFinal, "SuitIndex", "TEXT")

  with arcpy.da.UpdateCursor(FloodFinal, ['VALUE','SuitIndex']) as intfile:
      for row_intfile in intfile:
          # Suitability Criteria
          if row_intfile[0] == 1:
             row_intfile[1] = "Suitable Areas"  
          else:
             row_intfile[1] = "Unsuitable Areas"
             
          intfile.updateRow(row_intfile)

except:
  # Adding error massage if the script fail to run
  arcpy.AddError("Could not identify floodplains. Check error messages.")
  arcpy.AddError(arcpy.GetMessages())
  # Delete field "FloodValue"
  #arcpy.DeleteField_management(inputFloodFeature, "FloodValue")
  arcpy.Delete_management(clipFlood)

finally:
  try:
    # Delete field "FloodValue"
    #arcpy.DeleteField_management(inputFloodFeature, "FloodValue")
    arcpy.Delete_management(clipFlood)

    arcpy.AddMessage("Table containing suitable and unsuitable areas has been generated successfully in the output folder.")

  except:
    pass



